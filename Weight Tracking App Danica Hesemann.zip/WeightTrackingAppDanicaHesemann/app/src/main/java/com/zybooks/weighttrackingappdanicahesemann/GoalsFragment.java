package com.zybooks.weighttrackingappdanicahesemann;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class GoalsFragment extends Fragment {

    private final static String TAG = "GoalsFragment";

    public static final String EXTRA_USER = "com.zybooks.weighttrackingappdanicahesemann.user";

    private EditText goalText;
    private String activeUser;
    private String activeGoalType;
    private String newGoal;
    private WeightDatabase weightAppDb;
    private boolean goalEnabled;


    public GoalsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_goals, container, false);

        // Get the active user
        Intent intent = requireActivity().getIntent();
        activeUser = intent.getStringExtra(EXTRA_USER);

        // Get instance of the database
        weightAppDb = WeightDatabase.getInstance(requireActivity().getApplicationContext());

        // Declare UI components and variables
        RadioGroup goalType = view.findViewById(R.id.goalRadio);
        goalText = view.findViewById(R.id.editTextGoal);
        SwitchCompat enableGoal = view.findViewById(R.id.switchEnableGoal);
        Button saveButton = view.findViewById(R.id.buttonGoalSave);
        RadioButton loseButton = view.findViewById(R.id.loseRadio);
        RadioButton gainButton = view.findViewById(R.id.gainRadio);

        // Coordinate UI components and variables
        goalEnabled = enableGoal.isChecked();
        if (loseButton.isChecked()) {
            activeGoalType = "lose";
        }
        else if (gainButton.isChecked()) {
            activeGoalType = "gain";
        }
        else {
            activeGoalType = "maintain";
        }

        // Enable or disable the goal
        enableGoal.setOnCheckedChangeListener((buttonView, isChecked) -> {
            goalEnabled = isChecked;
            Log.d(TAG, "Goal enabled: " + goalEnabled);

        });

        // Change the goal type
        goalType.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.loseRadio) {
                activeGoalType = "lose";
            }
            else if (checkedId == R.id.gainRadio) {
                activeGoalType = "gain";
            }
            else {
                activeGoalType = "maintain";
            }
            Log.d(TAG, "Goal type: " + activeGoalType);
        });

        // Create or update the user's goal
        saveButton.setOnClickListener(v -> {
            // Checks if goal text is empty
            if ((goalText.getText().length() > 0) || !goalEnabled) {
                newGoal = goalText.getText().toString();

                // Sets goal type to off if goal is disabled
                if (!goalEnabled) {
                    activeGoalType = "off";
                }

                // Checks if there is a goal
                if (weightAppDb.getGoals(activeUser).size() > 0 ) {
                    // Retrieves the goal if there is one
                    Goal goal = weightAppDb.getGoals(activeUser).get(0);
                    if (!(goalText.getText().length() > 0)) {
                        newGoal = "000.0";
                    }
                    // Sets values
                    goal.setGoalString(newGoal);
                    goal.setGoalType(activeGoalType);
                    goal.setUserPhone(activeUser);
                    // Updates the goal
                    weightAppDb.updateGoal(goal);
                    Toast.makeText(getContext(), "Goal updated", Toast.LENGTH_LONG).show();
                }
                // If database has no goal
                else {
                    // Create a new goal and set values
                    Goal goal = new Goal();
                    if (!(goalText.getText().length() > 0)) {
                        newGoal = "000.0";
                    }
                    goal.setGoalString(newGoal);
                    goal.setGoalType(activeGoalType);
                    goal.setUserPhone(activeUser);
                    // Add the new goal to the database
                    weightAppDb.addGoal(goal);
                    Toast.makeText(getContext(), "New goal added", Toast.LENGTH_LONG).show();
                }
                Log.d(TAG, "Goals: " + weightAppDb.getGoals(activeUser));
            }
        });
        Log.d(TAG, "goalType: " + activeGoalType);
        Log.d(TAG, "goalEnabled: " + goalEnabled);
        return view;
    }
}