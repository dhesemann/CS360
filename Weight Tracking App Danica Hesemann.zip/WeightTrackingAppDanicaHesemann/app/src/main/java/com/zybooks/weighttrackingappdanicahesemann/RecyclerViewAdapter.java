package com.zybooks.weighttrackingappdanicahesemann;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    // Declare the RecyclerView and a list for the weights to display
    List<Weight> weightsList;
    RecyclerView recyclerView;

    // Define ViewHolder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // Declare variables
        private final TextView rowWeight;
        private final TextView rowDate;
        private Weight selectedWeight;

        // Constructor
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Set the date and weight in the UI
            rowWeight = itemView.findViewById(R.id.varWeight);
            rowDate = itemView.findViewById(R.id.varDate);

            // Define edit button and open EditWeightActivity when it is presesd
            Button editButton = itemView.findViewById(R.id.buttonEdit);
            editButton.setOnClickListener(v -> openEditActivity(v, selectedWeight));
        }
    }

    // data is passed into the constructor
    RecyclerViewAdapter(Context context, List<Weight> weightsList, RecyclerView recyclerView) {
        this.weightsList = weightsList;
        this.recyclerView = recyclerView;
    }

    // inflates the cell layout from xml when needed
    @Override
    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.cardview_layout, parent, false);
        return new ViewHolder(view);
    }

    // binds the data to the TextView in each cell
    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        Weight weight = weightsList.get(position);
        // Defines the selected weight
        viewHolder.selectedWeight = weight;
        viewHolder.rowWeight.setText(weight.getWeightString());
        viewHolder.rowDate.setText(weight.getDate());


    }

    // total number of cells
    @Override
    public int getItemCount() {
        return weightsList.size();
    }

    // Opens the EditWeightActivity with the active user and selected weight ID
    public static void openEditActivity(View v, Weight selected) {
        Intent intent = new Intent(v.getContext(), EditWeightActivity.class);
        intent.putExtra(EditWeightActivity.EXTRA_USER, MainActivity.getActiveUser());
        intent.putExtra(EditWeightActivity.EXTRA_WEIGHT_ID, (selected.getId()));
        v.getContext().startActivity(intent);
    }
}

