package com.zybooks.weighttrackingappdanicahesemann;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class WeightFragment extends Fragment {

    private final static String TAG = "WeightFragment";

    public static final String EXTRA_USER = "com.zybooks.weighttrackingappdanicahesemann.user";

    // Declare variables
    RecyclerViewAdapter recyclerAdapter;
    WeightDatabase weightAppDb;
    private String activeUser;
    private EditText addVal;


    public WeightFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weight, container, false);

        // Get active user
        Intent intent = requireActivity().getIntent();
        activeUser = intent.getStringExtra(EXTRA_USER);

        // Get instance of database
        weightAppDb = WeightDatabase.getInstance(requireActivity().getApplicationContext());

        // define UI components
        addVal = view.findViewById(R.id.editTextNewWeight);
        Button addButton = view.findViewById(R.id.buttonAddWeight);

        // When add button is pressed
        addButton.setOnClickListener(v -> {
            // Checks that EditText isn't empty
            if (addVal.getText().length() > 0) {
                // Make sure input is valid
                if (isFloat(addVal.getText().toString())) {
                    Log.d(TAG, "addVal = " + addVal);

                    // Creates a new weight with weight, date, and userPhone values
                    Weight newWeight = new Weight(addVal.getText().toString(), activeUser);
                    // Adds the weight to the database
                    weightAppDb.addWeight(newWeight);
                    Toast.makeText(getContext(), "Record added", Toast.LENGTH_LONG).show();

                    // Reopens the main activity to the dashboard
                    openMainActivity();
                }
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        // Set up RecyclerView and GridLayout
        RecyclerView recyclerView = requireView().findViewById(R.id.dataRecyclerView);
        int numberOfColumns = 2;
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), numberOfColumns));
        recyclerAdapter = new RecyclerViewAdapter(getActivity(), weightAppDb.getWeights(activeUser), recyclerView );
        recyclerView.setAdapter(recyclerAdapter);
    }

    // Opens the Main Activity
    public void openMainActivity() {
        Intent i = new Intent(getContext(), MainActivity.class);
        i.putExtra(MainActivity.EXTRA_USER, activeUser);
        startActivity(i);
    }

    public static boolean isFloat(String string) {
        try {
            Float.parseFloat(string);
            return true;
        } catch(NumberFormatException e) {
            e.printStackTrace();
        }
        return false;
    }
}