package com.zybooks.weighttrackingappdanicahesemann;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import java.util.ArrayList;
import java.util.List;

public class WeightDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight-app.db";
    private static final int VERSION = 1;

    private static WeightDatabase weightAppDb;

    // Method to get an instance of the database
    public static WeightDatabase getInstance(Context context) {
        if (weightAppDb == null) {
            weightAppDb = new WeightDatabase(context);
        }
        return weightAppDb;
    }

    // Constructor with context
    private WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Table to hold the weights
    private static final class WeightTable {
        private static final String TABLE = "weight";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT_LBS = "weight";
        private static final String COL_USER = "user";
    }

    // Table to hold phone numbers and passwords
    private static final class LoginTable {
        private static final String TABLE = "login";
        private static final String COL_PHONE = "phone";
        private static final String COL_PASSWORD = "password";
    }

    // Table to hold the user's goal
    private static final class GoalTable {
        private static final String TABLE = "goal";
        private static final String COL_ID = "_id";
        private static final String COL_GOAL = "goal";
        private static final String COL_TYPE = "goal_type";
        private static final String COL_USER = "user";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the tables in the database
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_PHONE + " TEXT PRIMARY KEY, " +
                LoginTable.COL_PASSWORD + " TEXT)");
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                WeightTable.COL_DATE + " TEXT, " +
                WeightTable.COL_WEIGHT_LBS + " REAL, " +
                WeightTable.COL_USER + " TEXT, " +
                "foreign key(" + WeightTable.COL_USER + ") references " +
                LoginTable.TABLE + "(" + LoginTable.COL_PHONE + ") on delete cascade)");
        db.execSQL("create table " + GoalTable.TABLE + " (" +
                GoalTable.COL_ID + " INTEGER PRIMARY KEY, " +
                GoalTable.COL_GOAL + " REAL, " +
                GoalTable.COL_TYPE + " TEXT, " +
                GoalTable.COL_USER + " TEXT, " +
                "foreign key(" + GoalTable.COL_USER + ") references " +
                LoginTable.TABLE + "(" + LoginTable.COL_PHONE + ") on delete cascade)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drops and rebuild the tables
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        db.execSQL("drop table if exists " + GoalTable.TABLE);
        onCreate(db);
    }

    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            db.setForeignKeyConstraintsEnabled(true);
        }
    }

    // Get a list of users
    public List<User> getUsers() {
        List<User> users = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String orderBy = LoginTable.COL_PHONE + " collate nocase";

        // Add each user to the list
        String sql = "select * from " + LoginTable.TABLE + " order by " + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setPhone(cursor.getString(0));
                user.setPassword(cursor.getString(1));
                users.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return users;
    }

    // Get one user
    public User getUser(String userPhone) {
        User user = null;

        SQLiteDatabase db = this.getReadableDatabase();
        // Select with phone number
        String sql = "select * from " + LoginTable.TABLE +
                " where " + LoginTable.COL_PHONE + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { userPhone });

        if (cursor.moveToFirst()) {
            user = new User();
            user.setPhone(cursor.getString(0));
            user.setPassword(cursor.getString(1));
        }
        cursor.close();

        return user;
    }

    // Add a new user to the database
    public void addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_PHONE, user.getPhone());
        values.put(LoginTable.COL_PASSWORD, user.getPassword());
        db.insert(LoginTable.TABLE, null, values);
    }

    // Delete a user from the database
    public void deleteUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(LoginTable.TABLE,
                LoginTable.COL_PHONE + " = ?", new String[] { user.getPhone() });
    }
    // Get a list of weight items
    public List<Weight> getWeights(String user) {
        List<Weight> weights = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        // Add each weight to the list
        String sql = "select * from " + WeightTable.TABLE +
                " where " + WeightTable.COL_USER + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { user });
        if (cursor.moveToFirst()) {
            do {
                Weight weight = new Weight();
                weight.setId(cursor.getInt(0));
                weight.setCustomDate(cursor.getString(1));
                weight.setWeightString(cursor.getString(2));
                weight.setUserPhone(cursor.getString(3));
                weights.add(weight);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return weights;
    }

    // Get one weight
    public Weight getWeight(long weightId) {
        Weight weight = null;

        // Search by ID
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + WeightTable.TABLE +
                " where " + WeightTable.COL_ID + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { Long.toString(weightId) });

        if (cursor.moveToFirst()) {
            weight = new Weight();
            weight.setId(cursor.getInt(0));
            weight.setCustomDate(cursor.getString(1));
            weight.setWeightString(cursor.getString(2));
            weight.setUserPhone(cursor.getString(3));
        }
        cursor.close();

        return weight;
    }

    // Add a new weight to the database
    public void addWeight(Weight weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT_LBS, weight.getWeight());
        values.put(WeightTable.COL_DATE, weight.getDate());
        values.put(WeightTable.COL_USER, weight.getUserPhone());
        long weightId = db.insert(WeightTable.TABLE, null, values);
        weight.setId(weightId);
    }

    // Change values for a weight
    public void updateWeight(Weight weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_ID, weight.getId());
        values.put(WeightTable.COL_WEIGHT_LBS, weight.getWeight());
        values.put(WeightTable.COL_DATE, weight.getDate());
        values.put(WeightTable.COL_USER, weight.getUserPhone());
        db.update(WeightTable.TABLE, values,
                WeightTable.COL_ID + " = " + weight.getId(), null);
    }

    // Delete a user from the database
    public void deleteWeight(long weightId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(WeightTable.TABLE,
                WeightTable.COL_ID + " = " + weightId, null);
    }

    // Get a list of goals
    public List<Goal> getGoals(String user) {
        List<Goal> goals = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        // Add each to the list
        String sql = "select * from " + GoalTable.TABLE +
                " where " + GoalTable.COL_USER + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { user });
        if (cursor.moveToFirst()) {
            do {
                Goal goal = new Goal();
                goal.setId(cursor.getInt(0));
                goal.setGoalString(cursor.getString(1));
                goal.setGoalType(cursor.getString(2));
                goal.setUserPhone(cursor.getString(3));
                goals.add(goal);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return goals;
    }

    // Add a new goal to the database
    public void addGoal(Goal goal) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalTable.COL_GOAL, goal.getGoal());
        values.put(GoalTable.COL_TYPE, goal.getGoalType());
        values.put(GoalTable.COL_USER, goal.getUserPhone());
        long goalId = db.insert(GoalTable.TABLE, null, values);
        goal.setId(goalId);
    }

    // Change values for a goal
    public void updateGoal(Goal goal) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalTable.COL_ID, goal.getId());
        values.put(GoalTable.COL_GOAL, goal.getGoal());
        values.put(GoalTable.COL_TYPE, goal.getGoalType());
        values.put(GoalTable.COL_USER, goal.getUserPhone());
        db.update(GoalTable.TABLE, values,
                GoalTable.COL_ID + " = " + goal.getId(), null);
    }

}
