package com.zybooks.weighttrackingappdanicahesemann;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;

public class DashboardFragment extends Fragment {

    private final static String TAG = "DashboardFragment";
    public static final String EXTRA_USER = "com.zybooks.weighttrackingappdanicahesemann.user";

    private String activeUser;
    private boolean goalEnabled;


    public DashboardFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        /* In the future, set up GraphView
           Adjust for one weight per date and graph weight over time
        * */

        // Get the active user
        Intent intent = requireActivity().getIntent();
        activeUser = intent.getStringExtra(EXTRA_USER);

        // Define UI components and variables
        WeightDatabase weightAppDb = WeightDatabase.getInstance(requireActivity().getApplicationContext());

        TextView remainingText = view.findViewById(R.id.remainingText);
        TextView lbsKgs = view.findViewById(R.id.textLbs);
        TextView goalMessage = view.findViewById(R.id.message);
        TextView goalText = view.findViewById(R.id.textGoal);
        TextView lbsKgs2 = view.findViewById(R.id.textLbs2);

        // Checks whether goal is enabled and stores the result
        if (weightAppDb.getGoals(activeUser).size() > 0) {
            if (!weightAppDb.getGoals(activeUser).get(0).getGoalType().equals("off")) {
                goalEnabled = true;
            }
        } else {
            goalEnabled = false;
        }

        // If goal is disabled, make all goal-related components invisible
        if (goalEnabled) {
            remainingText.setVisibility(View.VISIBLE);
            lbsKgs.setVisibility(View.VISIBLE);
            goalMessage.setVisibility(View.VISIBLE);
            goalText.setVisibility(View.VISIBLE);
            lbsKgs2.setVisibility(View.VISIBLE);
        } else {
            remainingText.setVisibility(View.INVISIBLE);
            lbsKgs.setVisibility(View.INVISIBLE);
            goalMessage.setVisibility(View.INVISIBLE);
            goalText.setVisibility(View.INVISIBLE);
            lbsKgs2.setVisibility(View.INVISIBLE);
        }

        // Check if goal exists
        if (weightAppDb.getGoals(activeUser).size() > 0) {
            // Check if any weights are entered in the database
            // Sets goal weight
            float goalWeight = weightAppDb.getGoals(activeUser).get(0).getGoal();
            float currentWeight;
            if (weightAppDb.getWeights(activeUser).size() > 0) {
                // Gets the index of the most recent weight entry
                int weightListIndex = (weightAppDb.getWeights(activeUser).size()) - 1;
                // Sets most recent weight entry to currentWeight value
                currentWeight = weightAppDb.getWeights(activeUser).get(weightListIndex).getWeight();

            }
            // For handling cases where there is a goal and no weights in the database
            else {
                currentWeight = -1;
            }

            Log.d(TAG, "currentWeight: " + currentWeight);
            Log.d(TAG, "goalWeight: " + goalWeight);
            Log.d(TAG, "verify 1 item in goals list: " + weightAppDb.getGoals(activeUser).size());

            // Declare variable to store the remaining weight
            float remaining;
            // Formula for remaining weight if goal is weight loss
            if (weightAppDb.getGoals(activeUser).get(0).getGoalType().equals("lose") && (currentWeight != -1)) {
                remaining = round((currentWeight - goalWeight), 1);
                // Sets remaining value to 0 and sends a message if goal is met
                if (remaining <= 0) {
                    remaining = 0.0F;
                    sendNotification();
                }
            }
            // Formula for remaining weight if goal is weight gain
            else if (weightAppDb.getGoals(activeUser).get(0).getGoalType().equals("gain") && (currentWeight != -1)) {
                remaining = round((goalWeight - currentWeight), 1);
                // Sets remaining value to 0 and sends a message if goal is met
                if (remaining <= 0) {
                    remaining = 0.0F;
                    sendNotification();
                }
            }
            // If no weights, just set the remaining weight to the goal weight
            else if (currentWeight == -1) {
                remaining = goalWeight;
            }
            // For maintenance, calculates proximity to goal, no message
            else {
                remaining = round(Math.abs(currentWeight - goalWeight), 1);
            }
            goalText.setText(Float.toString(goalWeight));
            remainingText.setText(Float.toString(remaining));
        }


        return view;
    }

    // Checks permissions and sends a text message notification
    private void sendNotification() {
        if (ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(activeUser, null, "Congratulations, you have reached your goal!", null, null);
            Toast.makeText(getContext(), "Goal reached, SMS notification sent", Toast.LENGTH_LONG).show();
        }
        else {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.SEND_SMS}, 100);
        }
    }


    // For rounding floats
    public static float round(float d, int decimalPlace) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }
}