package com.zybooks.weighttrackingappdanicahesemann;

public class User {

    // Define attributes
    private String phone;
    // In the future, hash the password
    private String password;

    // Constructor
    public User() {}

    // Constructor with phone and password
    public User(String newPhone, String newPassword) {
        phone = newPhone;
        password = newPassword;
    }

    // Gets and sets
    public String getPhone() { return phone; }

    public void setPhone(String newPhone) { phone = newPhone; }

    public String getPassword() { return password; }

    public void setPassword(String newPassword) { password = newPassword; }

}
