package com.zybooks.weighttrackingappdanicahesemann;

public class Goal {

    // Define attributes
    private long id;
    private float goal;
    private String userPhone;
    private String goalType;

    // Constructor
    public void Goal() {}

    // Get and sets
    public long getId() { return id; };

    public void setId(long newId) { id = newId; }

    public float getGoal() { return goal; }

    public void setGoal(float newGoal) { goal = newGoal; }

    public void setGoalString(String newGoal) { goal = Float.parseFloat(newGoal); }

    public String getUserPhone() { return userPhone; }

    public void setUserPhone(String forUser) { userPhone = forUser; }

    public String getGoalType() { return goalType; }

    public void setGoalType(String activeGoalType) { goalType = activeGoalType; }

}
