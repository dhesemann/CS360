package com.zybooks.weighttrackingappdanicahesemann;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Weight {
    // Define attributes
    private long id;
    private float weight;
    private String userPhone;
    private String date;

    // Constructor
    public Weight() {}

    // Constructor with weight and userPhone input
    public Weight(String newWeight, String forUser) {
        weight = Float.parseFloat(newWeight);
        // Date is set with actual date
        LocalDate localDate = LocalDate.now();
        date = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT).format(localDate);
        userPhone = forUser;
    }

    // Gets and sets
    public long getId() { return id; }

    public void setId(long newId) { id = newId; }

    public String getDate() { return date; }

    public void setCustomDate(String newDate) { date = newDate; }

    public float getWeight() { return weight; }

    public String getWeightString() {
        float roundedWeight = round(weight, 1);
        return Float.toString(roundedWeight); }

    public void setWeight(float newWeight) { weight = newWeight; }

    public void setWeightString(String newWeight) { weight = Float.parseFloat(newWeight); }

    public String getUserPhone() { return userPhone; }

    public void setUserPhone(String forUser) { userPhone = forUser; }

    // For rounding floats
    public static float round(float d, int decimalPlace) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }
}


