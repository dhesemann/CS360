package com.zybooks.weighttrackingappdanicahesemann;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class EditWeightActivity extends AppCompatActivity {

    public static final String EXTRA_WEIGHT_ID = "com.zybooks.weighttrackingappdanicahesemann.weight_id";
    public static final String EXTRA_USER = "com.zybooks.weighttrackingappdanicahesemann.user";

    // Declare variables
    private long selectedWeight;
    private WeightDatabase weightAppDb;
    private EditText newWeight;
    private Weight weightItem;
    private String activeUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weight);

        // Get active user and selected weight ID
        Intent intent = getIntent();
        selectedWeight = intent.getLongExtra(EXTRA_WEIGHT_ID, 0);
        activeUser = intent.getStringExtra(EXTRA_USER);

        // Get instance of database
        weightAppDb = WeightDatabase.getInstance(getApplicationContext());

        // Get the selected weight item from the database
        weightItem = weightAppDb.getWeight(selectedWeight);

        // Define UI components
        TextView itemDate = findViewById(R.id.varDate);
        itemDate.setText(weightAppDb.getWeight(selectedWeight).getDate());
        TextView currentWeight = findViewById(R.id.varWeight);
        currentWeight.setText(weightAppDb.getWeight(selectedWeight).getWeightString());
        newWeight = findViewById(R.id.editTextUpdatedWeight);
        Button updateButton = findViewById(R.id.buttonUpdate);
        Button deleteButton = findViewById(R.id.buttonDelete);

        // Update the item's weight and update the database
        updateButton.setOnClickListener(v -> {
            String updatedWeight;
            updatedWeight = newWeight.getText().toString();
            // Make sure input is valid
            if (isFloat(updatedWeight)) {
                weightItem.setWeightString(updatedWeight);
                weightAppDb.updateWeight(weightItem);
                // Open MainActivity
                openMainActivity();
            }
        });

        deleteButton.setOnClickListener(v -> {
            // Delete the selected item
            weightAppDb.deleteWeight(selectedWeight);
            // Open MainActivity
            openMainActivity();
        });

    }

    // Open the Main activity
    public void openMainActivity() {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra(MainActivity.EXTRA_USER, activeUser);
        startActivity(i);
    }

    public static boolean isFloat(String string) {
        try {
            Float.parseFloat(string);
            return true;
        } catch(NumberFormatException e) {
            e.printStackTrace();
            return false;
        }
    }
}