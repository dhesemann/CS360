package com.zybooks.weighttrackingappdanicahesemann;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private final static String TAG = "LoginActivity";

    // Declare UI components and database
    private EditText phoneText;
    private EditText passwordText;
    private WeightDatabase weightAppDb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Get instance of the database
        weightAppDb = WeightDatabase.getInstance(getApplicationContext());

        // Define UI variables
        Button loginButton = findViewById(R.id.loginButton);
        Button signupButton = findViewById(R.id.signupButton);
        Button deleteAccountButton = findViewById(R.id.buttonDeleteAccount);
        phoneText = findViewById(R.id.editTextPhone);
        passwordText = findViewById(R.id.editTextPassword);


        // Call the appropriate methods from the correct buttons
        loginButton.setOnClickListener(v -> onLogin(phoneText.getText().toString(), passwordText.getText().toString()));
        signupButton.setOnClickListener(v -> onRegister(phoneText.getText().toString(), passwordText.getText().toString()));
        deleteAccountButton.setOnClickListener(v -> onDeleteAccount(phoneText.getText().toString(), passwordText.getText().toString()));
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    // Open the main activity and pass it the active user
    public void openMain(User activeUser) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(MainActivity.EXTRA_USER, activeUser.getPhone());
        startActivity(intent);
    }

    // Called when Login button is pressed
    public void onLogin(String userPhone, String userPassword) {
        // Checks that length is 10+ digits
        // In the future, should account for invalid phone numbers
        if (phoneText.getText().length() > 9) {
            // Phone number is not in the database
            if (weightAppDb.getUser(userPhone) == null) {
                Toast.makeText(this, "Phone number not registered", Toast.LENGTH_LONG).show();
            }
            // Password does not match phone in database
            else if (!weightAppDb.getUser(userPhone).getPassword().equals(userPassword)) {
                Toast.makeText(this, "Incorrect password", Toast.LENGTH_LONG).show();
            }
            // Successful, opens main activity
            else {
                openMain(weightAppDb.getUser(userPhone));
            }
        }
        // If phone number is less than 10 characters
        else {
            Toast.makeText(this, "Phone number too short", Toast.LENGTH_LONG).show();
        }
        Log.d(TAG, "Users: " + weightAppDb.getUsers());
    }

    // Called when sign up button is pressed
    public void onRegister(String userPhone, String userPassword) {
        // Checks that phone number is at least 10 characters
        if (phoneText.getText().length() > 9) {
            // Phone number already in the database
            if (weightAppDb.getUser(userPhone) != null) {
                Toast.makeText(this, "Phone number already registered", Toast.LENGTH_LONG).show();
            }
            // Checks that password is 8 characters or more
            // In the future, should also verify with second password input
            else if (passwordText.toString().length() < 8) {
                Toast.makeText(this, "Password is too short", Toast.LENGTH_LONG).show();
            }
            // If phone and password are valid, create user in the database and open main activity
            else {
                User newUser = new User(userPhone, userPassword);
                weightAppDb.addUser(newUser);
                Toast.makeText(this, "User added", Toast.LENGTH_LONG).show();
                openMain(weightAppDb.getUser(userPhone));
            }
        }
    }

    // Called when delete button is pressed
    public void onDeleteAccount(String userPhone, String userPassword) {
        // Checks that the phone number exists
        if (weightAppDb.getUser(userPhone) == null) {
            Toast.makeText(this, "Phone number not registered", Toast.LENGTH_LONG).show();
        }
        // Checks that the password is correct
        else if (!weightAppDb.getUser(userPhone).getPassword().equals(userPassword)) {
            Toast.makeText(this, "Incorrect password", Toast.LENGTH_LONG).show();
        }
        // If phone and password are in the database, deletes the user
        else {
            weightAppDb.deleteUser(weightAppDb.getUser(userPhone));
            Toast.makeText(this, "User removed", Toast.LENGTH_LONG).show();
        }
    }
}